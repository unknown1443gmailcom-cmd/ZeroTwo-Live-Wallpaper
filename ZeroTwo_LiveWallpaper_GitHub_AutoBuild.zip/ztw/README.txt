ZERO TWO LIVE WALLPAPER

What it does:
- Uses the supplied Zero Two image as the open-eyes frame.
- Uses a matching closed-eyes frame.
- When Android makes the wallpaper visible (screen wake/unlock), it cross-fades
  from closed eyes to open eyes over about 0.42 seconds.
- When the wallpaper becomes hidden (screen off), it switches to the closed-eye frame.

Install/build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the APK.
5. Open the Android wallpaper picker and select "Zero Two Live Wallpaper".

Note:
The 8K files are high-quality upscales of the supplied/source images; they are
not native 8K captures. The live wallpaper app uses smaller 4K-class assets to
reduce RAM usage on Android phones.