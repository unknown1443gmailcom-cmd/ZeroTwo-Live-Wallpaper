package com.example.zerotwolive

import android.graphics.*
import android.os.*
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import kotlin.math.max
import kotlin.math.min

class ZeroTwoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = ZeroTwoEngine()

    private inner class ZeroTwoEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private val openBitmap by lazy { BitmapFactory.decodeResource(resources, R.drawable.zero_two_open) }
        private val closedBitmap by lazy { BitmapFactory.decodeResource(resources, R.drawable.zero_two_closed) }

        private var visibleNow = false
        private var progress = 1f
        private var animStart = 0L
        private var animating = false

        private val frame = object : Runnable {
            override fun run() {
                if (!visibleNow || !animating) return
                val elapsed = SystemClock.uptimeMillis() - animStart
                progress = min(1f, elapsed / 420f)
                drawFrame()
                if (progress < 1f) handler.postDelayed(this, 16L)
                else animating = false
            }
        }

        override fun onVisibilityChanged(visible: Boolean) {
            visibleNow = visible
            if (visible) {
                // Screen wakes: start from closed and smoothly open the eyes.
                progress = 0f
                animStart = SystemClock.uptimeMillis()
                animating = true
                handler.removeCallbacks(frame)
                handler.post(frame)
            } else {
                // Screen goes off: prepare closed-eye state.
                progress = 0f
                animating = false
                handler.removeCallbacks(frame)
                drawFrame()
            }
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visibleNow = false
            handler.removeCallbacks(frame)
            super.onSurfaceDestroyed(holder)
        }

        private fun drawFrame() {
            val holder = surfaceHolder ?: return
            val canvas = try { holder.lockCanvas() } catch (_: Exception) { null } ?: return
            try {
                val w = canvas.width.toFloat()
                val h = canvas.height.toFloat()

                // Center-crop the image to the phone screen.
                val bitmap = if (visibleNow) openBitmap else closedBitmap
                val scale = max(w / bitmap.width, h / bitmap.height)
                val dw = bitmap.width * scale
                val dh = bitmap.height * scale
                val left = (w - dw) / 2f
                val top = (h - dh) / 2f

                // During wake-up, cross-fade closed -> open.
                if (visibleNow && animating) {
                    canvas.drawColor(Color.BLACK)
                    paint.alpha = ((1f - progress) * 255).toInt()
                    canvas.drawBitmap(closedBitmap, null,
                        RectF(left, top, left + dw, top + dh), paint)
                    paint.alpha = (progress * 255).toInt()
                    canvas.drawBitmap(openBitmap, null,
                        RectF(left, top, left + dw, top + dh), paint)
                    paint.alpha = 255
                } else {
                    paint.alpha = 255
                    canvas.drawBitmap(bitmap, null,
                        RectF(left, top, left + dw, top + dh), paint)
                }
            } finally {
                holder.unlockCanvasAndPost(canvas)
            }
        }
    }
}