ZERO TWO LIVE WALLPAPER - PHONE-ONLY BUILD

1. Create a GitHub repository (Public or Private).
2. Upload all files from this ZIP into the repository.
3. Open the repository -> Actions.
4. Select "Build Zero Two Live Wallpaper APK".
5. Tap "Run workflow" if needed.
6. Wait for the build to finish with a green check.
7. Open the completed workflow run and download the artifact named:
   ZeroTwo-Live-Wallpaper-APK
8. Extract the ZIP and install app-debug.apk on your Android phone.

The workflow uses JDK 17 and Gradle 8.10.2 in GitHub's cloud runner.
